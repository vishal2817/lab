package sample;

public class result {
	public static void main(String[] args) {
		int num = 2345;
		int add = 8;
		double res=(((num+add)/3)%5)*5;
		System.out.println("The Final Result is : "+ res);

	}
}
