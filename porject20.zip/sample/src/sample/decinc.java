package sample;

public class decinc {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
					int val=10,val2=10;
				// Incrementing both pre and post fix
				System.out.println("Incrementing both pre and post fix");
				System.out.println("Post Increment: " +val++);
				System.out.println("Pre Increment: "+(++val));
				
				// Decrementing both pre and post fix
						System.out.println("Decrementing both pre and post fix");
						System.out.println("Post Decrement: " +val--);
						System.out.println("Pre Decrement: "+(--val));
			}
}
