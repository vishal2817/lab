package sample;

public class args {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=10;
		num1+=5;//action of num1=num1+5
		System.out.println("The output of num1+=5 is"+num1);
		num1-=5;//action of num1=num1-5
		System.out.println("The output of num1-=5 is"+num1);
		num1*=5;//action of num1=num1*5
		System.out.println("The output of num1*=5 is"+num1);
		num1/=5;//action of num1=num1/5
		System.out.println("The output of num1/=5 is"+num1);
		num1%=5;//action of num1=num1%5
		System.out.println("The output of num1%=5 is"+num1); 
}
}
